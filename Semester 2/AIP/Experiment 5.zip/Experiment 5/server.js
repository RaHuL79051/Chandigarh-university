const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");

const app = express();
const PORT = 3000;

// MongoDB Connection
const mongoURI = "mongodb://localhost:27017/mydatabase"; // Replace with your MongoDB URI
mongoose.connect(mongoURI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log("MongoDB connected"))
  .catch(err => console.log(err));

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static("public"));

// User Model
const UserSchema = new mongoose.Schema({
  name: String,
  email: String
});
const User = mongoose.model("User", UserSchema);

// Serve the frontend
app.get("/", (req, res) => {
  res.sendFile(__dirname + "/public/index.html");
});

// Fetch all users
app.get("/get-users", async (req, res) => {
  const users = await User.find();
  res.json(users);
});

// Add a user
app.post("/add-user", async (req, res) => {
  const { name, email } = req.body;
  const newUser = new User({ name, email });
  await newUser.save();
  res.json({ message: "User added successfully!" });
});

// Delete a user
app.delete("/delete-user/:id", async (req, res) => {
  await User.findByIdAndDelete(req.params.id);
  res.json({ message: "User deleted successfully!" });
});

// Update a user
app.put("/update-user/:id", async (req, res) => {
  const { name, email } = req.body;
  await User.findByIdAndUpdate(req.params.id, { name, email });
  res.json({ message: "User updated successfully!" });
});

// Start server
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
